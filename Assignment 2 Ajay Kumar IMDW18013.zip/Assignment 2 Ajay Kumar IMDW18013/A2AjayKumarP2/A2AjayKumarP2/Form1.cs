﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A2AjayKumarP2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try {
                string rad, hei, len, wid;

                rad = textBox1.Text;
                hei = textBox2.Text;
                len = textBox3.Text;
                wid = textBox4.Text;

                double r, h, l, w, PI, x, vs, vc, vr;

                r = double.Parse(rad);
                h = double.Parse(hei);
                l = double.Parse(len);
                w = double.Parse(wid);


                PI = 3.14159;


                vs = (4.0 / 3) * PI * r * r * r;

                vc = (PI) * (r * r) * (h);

                vr = l * w * h;

                if (radioButton1.Checked)
                {
                    label6.Text = vs.ToString();
                    textBox2.Text = ("-");
                    textBox3.Text = ("-");
                    textBox4.Text = ("-");
                }
                else if (radioButton2.Checked)
                {
                    label6.Text = vc.ToString();
                    textBox3.Text = ("-");
                    textBox4.Text = ("-");

                }
                else if (radioButton3.Checked)
                {
                    label6.Text = vr.ToString();
                    textBox1.Text = ("-");
                }

            }
            catch
            {
                MessageBox.Show("Please Enter all Values");
            }






        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
