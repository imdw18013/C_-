﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A2AjayKumarP1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try {


                double F;
                int age;

                int.TryParse(textBox1.Text, out age);

                label3.Text = "";
                label2.Text = "";
                label10.Text = "";
                label11.Text = "";
                label12.Text = "";


                if (radioButton1.Checked)//on chechked radio button 1 following function will be performed.
                {
                    //STEP 1

                    label3.Text = "I am a citizen of Canada";
                    if (age == 0)
                    {
                        MessageBox.Show("Please enter all the values");
                    }
                    else if (age == 18 || age < 18)
                    {
                        F = 300 + (300 * .13);
                        label10.Text = "300";
                        label11.Text = "0";
                        label12.Text = "39";

                        //STEP 2 for age less than 18
                        if (radioButton3.Checked)
                        {
                            F = F + (250 + (250 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "300";
                            label11.Text = "0";
                            label12.Text = "39";
                            label14.Text = "282.5";
                        }
                        else if (radioButton4.Checked)
                        {
                            F = F + (220 + (220 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "300";
                            label11.Text = "0";
                            label12.Text = "39";
                            label14.Text = "248.6";

                        }
                        else if (radioButton5.Checked)
                        {
                            F = F + (150 + (150 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "300";
                            label11.Text = "0";
                            label12.Text = "39";
                            label14.Text = "169.5";
                        }
                    }
                    else if (age == 19 || age < 50)
                    {
                        F = 500 + (500 * .13);
                        label10.Text = "500";
                        label11.Text = "0";
                        label12.Text = "65";

                        //STEP 2 for age less than 50 or =19
                        if (radioButton3.Checked)
                        {
                            F = F + (250 + (250 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "500";
                            label11.Text = "0";
                            label12.Text = "39";
                            label14.Text = "282.5";
                        }
                        else if (radioButton4.Checked)
                        {
                            F = F + (220 + (220 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "500";
                            label11.Text = "0";
                            label12.Text = "39";
                            label14.Text = "248.6";

                        }
                        else if (radioButton5.Checked)
                        {
                            F = F + (150 + (150 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "500";
                            label11.Text = "0";
                            label12.Text = "39";
                            label14.Text = "169.5";
                        }
                    }
                    else if (age == 50 || age > 50)
                    {
                        F = 400 + (400 * .13);
                        label10.Text = "400";
                        label11.Text = "0";
                        label12.Text = "52";

                        //STEP 2 for age more than 50
                        if (radioButton3.Checked)
                        {
                            F = F + (250 + (250 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "400";
                            label11.Text = "0";
                            label12.Text = "39";
                            label14.Text = "282.5";
                        }
                        else if (radioButton4.Checked)
                        {
                            F = F + (220 + (220 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "400";
                            label11.Text = "0";
                            label12.Text = "39";
                            label14.Text = "248.6";

                        }
                        else if (radioButton5.Checked)
                        {
                            F = F + (150 + (150 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "400";
                            label11.Text = "0";
                            label12.Text = "39";
                            label14.Text = "169.5";
                        }
                    }

                }
                else
                {
                    label3.Text = "I am an International Student";

                    if (age == 0)
                    {
                        MessageBox.Show("Please enter all the values");
                    }
                    else if (age == 18 || age < 18)
                    {
                        F = (300 + 100) + (300 * .13);
                       // label2.Text += F.ToString("c");
                        label10.Text = "300";
                        label11.Text = "100";
                        label12.Text = "39";

                        //STEP 2 for age less than 18
                        if (radioButton3.Checked)
                        {
                            F = F + (250 + (250 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "300";
                            label11.Text = "100";
                            label12.Text = "39";
                            label14.Text = "282.5";
                        }
                        else if (radioButton4.Checked)
                        {
                            F = F + (220 + (220 * 0.13));
                            //label2.Text += F.ToString("c");
                            label10.Text = "300";
                            label11.Text = "100";
                            label12.Text = "39";
                            label14.Text = "248.6";

                        }
                        else if (radioButton5.Checked)
                        {
                            F = F + (150 + (150 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "300";
                            label11.Text = "100";
                            label12.Text = "39";
                            label14.Text = "169.5";
                        }

                    }
                    else if (age == 19 || age < 50)
                    {
                        F = (500 + 100) + (500 * .13);
                       // label2.Text += F.ToString("c");
                        label10.Text = "500";
                        label11.Text = "100";
                        label12.Text = "65";

                        //STEP 2 for age less than 50 or =19
                        if (radioButton3.Checked)
                        {
                            F = F + (250 + (250 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "500";
                            label11.Text = "100";
                            label12.Text = "39";
                            label14.Text = "282.5";
                        }
                        else if (radioButton4.Checked)
                        {
                            F = F + (220 + (220 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "500";
                            label11.Text = "100";
                            label12.Text = "39";
                            label14.Text = "248.6";

                        }
                        else if (radioButton5.Checked)
                        {
                            F = F + (150 + (150 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "500";
                            label11.Text = "100";
                            label12.Text = "39";
                            label14.Text = "169.5";
                        }
                    }
                    else if (age == 50 || age > 50)
                    {
                        F = (400 + 100) + (400 * .13);
                        // label2.Text += F.ToString("c");
                        label10.Text = "400";
                        label11.Text = "100";
                        label12.Text = "52";

                        //STEP 2 for age more than 50
                        if (radioButton3.Checked)
                        {
                            F = F + (250 + (250 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "400";
                            label11.Text = "100";
                            label12.Text = "39";
                            label14.Text = "282.5";
                        }
                        else if (radioButton4.Checked)
                        {
                            F = F + (220 + (220 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "400";
                            label11.Text = "100";
                            label12.Text = "39";
                            label14.Text = "248.6";

                        }
                        else if (radioButton5.Checked)
                        {
                            F = F + (150 + (150 * 0.13));
                            label2.Text += F.ToString("c");
                            label10.Text = "400";
                            label11.Text = "100";
                            label12.Text = "39";
                            label14.Text = "169.5";
                        }
                    }

                }
            }
            catch
            {
                MessageBox.Show("Please fill all the information");
            }


        }
    }
    }


