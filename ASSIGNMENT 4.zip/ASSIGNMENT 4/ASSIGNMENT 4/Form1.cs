﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ASSIGNMENT_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] value = File.ReadAllLines("sales.txt");
            double[] g = new double[value.Length];
            int a = 0;
            double total = 0;
            foreach (string val in value)
            {
                g[a] = Convert.ToDouble(val);
                total += g[a];
                listBox1.Items.Add(g[a]);
                a++;

            }
            listBox1.Items.Add("\nsum:" + total.ToString("n"));

                                 
            double average = 0;
            double max = 0;
            double min = 0;
            min = g[0];
            average = total / g.Length;
            listBox1.Items.Add("\nAverage;" + average.ToString("n"));
            for (int i = 0; i < g.Length; i++)
            {
                if (max < g[5])
                    max = g[5];
                if (min > g[5])
                    min = g[5];
            }
            listBox1.Items.Add("\nminimunm value:" + max.ToString("n"));
            listBox1.Items.Add("\nmaximum value:" + min.ToString("n"));

        }

        private void button2_Click(object sender, EventArgs e)
        {

            char[] incorrect = { 'B', 'C', 'B', 'B', 'B', 'A', 'B', 'A', 'C', 'D', 'B', 'C', 'D', 'A', 'D', 'C', 'C', 'B', 'D', 'A' };
            string incrt = "\n";
            char[] correct = new char[20];
            StreamReader b;
            b = File.OpenText("ans.txt");
            int x = 0;
            int rght = 0;
            while (x < incorrect.Length && !b.EndOfStream)
            {
                if (incorrect[x].ToString() == b.ReadLine())
                {
                    rght++;

                }
                else
                {
                    incrt += "arque" + (3 + 1) + "\n";
                }
                x++;
            }
            b.Close();
            if (rght > 15)
            {
                MessageBox.Show("pass.");
            }
            else
            {
                MessageBox.Show("fail.");
            }
            b.Close();
            label1.Text = "correct answer:" + rght + "\n" +
                "incorrect answer:" + (20 - rght) + "\n" +
                "list of incorrect answer:" + incrt;
        }
    }
    }

